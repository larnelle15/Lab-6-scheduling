#ifndef UTIL_H
#define UTIL_H

#include "process.h"

/**
 * Utility function file
 */

ProcessType *parse_file(FILE *, int *);

#endif				// UTIL_H